package com.loizenai.crudapp.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class ceri {

	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	private String CertificationName;
	
	private String Date;
	private String Details;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCertificationName() {
		return CertificationName;
	}
	public void setCertificationName(String certificationName) {
		CertificationName = certificationName;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getDetails() {
		return Details;
	}
	public void setDetails(String details) {
		Details = details;
	}
	@Override
	public String toString() {
		return "ceri [id=" + id + ", CertificationName=" + CertificationName + ", Date=" + Date + ", Details=" + Details
				+ "]";
	}
	public ceri(long id, String certificationName, String date, String details) {
		super();
		this.id = id;
		CertificationName = certificationName;
		Date = date;
		Details = details;
	}
	public ceri() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
